/// <reference path="../../../built/Lib/akra.d.ts"/>
/// <reference path="../../../built/Lib/progress.addon.d.ts"/>
/// <reference path="../../../built/Lib/base3dObjects.addon.d.ts"/>
/// <reference path="../../../built/Lib/compatibility.addon.d.ts"/>
/// <reference path="../idl/3d-party/dat.gui.d.ts" />

var akra;
(function (akra) {
    akra.addons.compatibility.verify("non-compatible");

    var pProgress = new akra.addons.Progress(document.getElementById("progress"));
    var pRenderOpts = {
        premultipliedAlpha: false,
        //for screenshoting
        preserveDrawingBuffer: true,
        //for black background & and avoiding composing with other html
        alpha: true
    };

    var pDeps = {
        root: "./",
        files: [{"path":"atmospheric_scattering.map","type":"map"}]
    };

    var pOptions = {
        renderer: pRenderOpts,
        progress: pProgress.getListener(),
        deps: pDeps
    };

    akra.pEngine = akra.createEngine(pOptions);

    var pCamera = null;
    var pViewport = null;
    var pScene = akra.pEngine.getScene();
    var pCanvas = akra.pEngine.getRenderer().getDefaultCanvas();
    var pKeymap = akra.control.createKeymap();
    var pComposer = akra.pEngine.getComposer();

    akra.pDragon = null;

    var pRmgr = akra.pEngine.getResourceManager();

    function createModelEntry(sResource) {
        var pModel = pRmgr.getColladaPool().findResource(sResource);
        var pModelRoot = pModel.attachToScene(pScene.getRootNode());

        return pModelRoot;
    }

    function setup() {
        var pCanvasElement = pCanvas._pCanvas;
        var pDiv = document.createElement("div");

        document.body.appendChild(pDiv);
        pDiv.appendChild(pCanvasElement);
        pDiv.style.position = "fixed";

        pKeymap.captureMouse(pCanvas.getElement());
        pKeymap.captureKeyboard(document);
    }

    function createCameras() {
        pCamera = pScene.createCamera();
        pCamera.attachToParent(pScene.getRootNode());

        pCamera.setRotationByXYZAxis(0., Math.PI, 0.);
        //pCamera.setPosition(-0.3016333281993866, 0.6858968138694763, -0.8825510144233704);
        //{ x: 0.008565357068199952, y: 0.9979711939303939, z: -0.019909111055309386, w: -0.059864497313835335 }
        // pCamera.farPlane = MAX_UINT16;
        // pCamera.lookAt(vec3(0.));
    }

    function createViewports() {
        pViewport = pCanvas.addViewport(new akra.render.LPPViewport(pCamera));
        pCanvas.resize(window.innerWidth, window.innerHeight);
        window.onresize = function (event) {
            pCanvas.resize(window.innerWidth, window.innerHeight);
        };
    }

    function createLighting() {
        var pSunLight = pScene.createLightPoint(2 /* OMNI */, true, 2048, "sun");

        pSunLight.attachToParent(pScene.getRootNode());
        pSunLight.setEnabled(true);
        pSunLight.getParams().ambient.set(.1, .1, .1, 1);
        pSunLight.getParams().diffuse.set(0.75);
        pSunLight.getParams().specular.set(1.);
        pSunLight.getParams().attenuation.set(1.25, 0, 0);

        pSunLight.addPosition(10, 10, 0);
    }

    var v3fOffset = new akra.Vec3;
    function updateKeyboardControls(fLateralSpeed, fRotationSpeed) {
        if (pKeymap.isKeyPress(39 /* RIGHT */)) {
            pCamera.addRelRotationByEulerAngles(0.0, 0.0, -fRotationSpeed);
            //v3fCameraUp.Z >0.0 ? fRotationSpeed: -fRotationSpeed);
        } else if (pKeymap.isKeyPress(37 /* LEFT */)) {
            pCamera.addRelRotationByEulerAngles(0.0, 0.0, fRotationSpeed);
            //v3fCameraUp.Z >0.0 ? -fRotationSpeed: fRotationSpeed);
        }

        if (pKeymap.isKeyPress(38 /* UP */)) {
            pCamera.addRelRotationByEulerAngles(0, fRotationSpeed, 0);
        } else if (pKeymap.isKeyPress(40 /* DOWN */)) {
            pCamera.addRelRotationByEulerAngles(0, -fRotationSpeed, 0);
        }

        v3fOffset.set(0.);
        var isCameraMoved = false;

        if (pKeymap.isKeyPress(68 /* D */)) {
            v3fOffset.x = fLateralSpeed;
            isCameraMoved = true;
        } else if (pKeymap.isKeyPress(65 /* A */)) {
            v3fOffset.x = -fLateralSpeed;
            isCameraMoved = true;
        }
        if (pKeymap.isKeyPress(82 /* R */)) {
            v3fOffset.y = fLateralSpeed;
            isCameraMoved = true;
        } else if (pKeymap.isKeyPress(70 /* F */)) {
            v3fOffset.y = -fLateralSpeed;
            isCameraMoved = true;
        }
        if (pKeymap.isKeyPress(87 /* W */)) {
            v3fOffset.z = -fLateralSpeed;
            isCameraMoved = true;
        } else if (pKeymap.isKeyPress(83 /* S */)) {
            v3fOffset.z = fLateralSpeed;
            isCameraMoved = true;
        }

        if (isCameraMoved) {
            pCamera.addRelPosition(v3fOffset);
        }
    }

    function updateCameras() {
        updateKeyboardControls(0.25, 0.05);

        //default camera.
        if (pKeymap.isMousePress() && pKeymap.isMouseMoved()) {
            var v2fD = pKeymap.getMouseShift();
            var fdX = v2fD.x, fdY = v2fD.y;

            fdX /= pCanvas.getWidth() / 10.0;
            fdY /= pCanvas.getHeight() / 10.0;

            pCamera.addRelRotationByEulerAngles(-fdX, -fdY, 0);
        }
    }
    akra.pCylinder = null;

    function createSceneEnvironment(pRoot) {
        if (typeof pRoot === "undefined") { pRoot = pScene.getRootNode(); }
        akra.addons.createQuad(pScene, 600.).attachToParent(pRoot);
        //pCylinder = addons.cylinder(pScene, 5., 5., 5., 100, 1, true);
        //pCylinder.setPosition(0, 4., 0);
        //pCylinder.attachToParent(pRoot);
        //pCylinder.getScene().beforeUpdate.connect(() => {
        //	pCylinder.addRotationByXYZAxis(0.002, 0.002, 0.002);
        //});
    }

    // var T = 0.0;
    akra.pSky = null;

    function update() {
        akra.pDragon.addRotationByEulerAngles(0.01, 0., 0.0);
        updateCameras();
        pKeymap.update();
        // pSky.setTime(T);
        // T += 0.02;
        // console.log(T);
    }

    var pParams = [
        "_fKr",
        "_fKm",
        "_fESun",
        "_fg",
        "_fExposure",
        "_fInnerRadius",
        "_fRayleighScaleDepth",
        "_fMieScaleDepth"
    ];

    akra.pLight = null;

    function main(pEngine) {
        setup();

        createCameras();
        createViewports();

        createSceneEnvironment();

        //pDragon = createModelEntry("CUBE.DAE");
        akra.pDragon = createModelEntry("SEYMOURPLANE.DAE");

        //pDragon.addOrbitRotationByXYZAxis(-math.HALF_PI, 0., 0).update();
        akra.pDragon.setPosition(0., 1, 0.).scale(.25).update();

        //createLighting();
        akra.pSky = new akra.model.Sky(pEngine, 32, 32, 1000.0);
        akra.pSky.setTime(13);

        //pSky.sun.setEnabled(false);
        pCamera.setRotationByForwardUp(akra.pSky.getSunDirection().negate(akra.Vec3.temp()), akra.Vec3.temp(0, 1., 0));
        pCamera.setPosition(-0.7, 0.9356149435043335, -12.079059600830078);
        pCamera.update();

        var pSceneModel = akra.pSky.skyDome;

        pSceneModel.attachToParent(pScene.getRootNode());

        // pSceneModel.accessLocalBounds().set(MAX_UINT16, MAX_UINT16, MAX_UINT16);
        // pScene.recursiveUpdate();
        // console.log(pSceneModel.worldBounds.toString());
        pKeymap.bind("P", function () {
            pSceneModel.getMesh().getSubset(0).wireframe(true);
        });

        pKeymap.bind("M", function () {
            pSceneModel.getMesh().getSubset(0).wireframe(false);
        });

        //pLight = <IOmniLight>pScene.createLightPoint(ELightTypes.OMNI, false);
        //pLight.attachToParent(pScene.getRootNode());
        //pLight.setPosition(0, 10, 0);
        //pLight.setEnabled(true);
        //pLight.getParams().diffuse.set(1);
        //pLight.getParams().attenuation.set(1, 0, 0);
        var pGUI = new dat.GUI();
        pGUI.add(pComposer, "kFixNormal", 0., 1.).step(0.01).name("light transmission");
        pGUI.add(pComposer, "fSunSpecular", 0., 1.).step(0.01).name("sun specular");
        pGUI.add(pComposer, "fSunAmbient", 0., 1.).step(0.01).name("sun ambient");

        var pFog = pGUI.addFolder("fog");
        pFog.add(pComposer, "cHeightFalloff", 0., 1.).step(0.01).name("height falloff");
        pFog.add(pComposer, "cGlobalDensity", 0., 0.25).step(0.001).name("global density");

        //pGUI.add(pSky, "_nHorinLevel", 1., pSky.getSize()).step(1.).name("horizont level").onChange(() => { pSky.setTime(pSky.time);});
        pGUI.add({ time: akra.pSky.time }, "time", 0., 24).step(0.1).onChange(function (t) {
            akra.pSky.setTime(t);
        });

        var f = pGUI.addFolder("wave length");
        var v3fWaveLength = akra.pSky.getWaveLength(new akra.Vec3);
        var cb = function () {
            akra.pSky.setWaveLength(v3fWaveLength);
            akra.pSky.setTime(akra.pSky.time);
        };
        f.add(v3fWaveLength, "x").min(0.).onChange(cb);
        f.add(v3fWaveLength, "y").min(0.).onChange(cb);
        f.add(v3fWaveLength, "z").min(0.).onChange(cb);

        //cHeightFalloff
        //cGlobalDensity
        //_nHorinLevel -- // pSky.setTime(_fLastTime);
        pScene.beforeUpdate.connect(update);

        pProgress.destroy();
        pEngine.exec();
    }

    akra.pEngine.ready(main);
})(akra || (akra = {}));
