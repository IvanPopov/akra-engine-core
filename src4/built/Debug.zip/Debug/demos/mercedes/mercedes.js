/// <reference path="../../../built/Lib/akra.d.ts" />
/// <reference path="../../../built/Lib/base3dObjects.addon.d.ts" />
var akra;
(function (akra) {
    (function (std) {
        /**
        * Append canvas element to DOM. Default to document.body.
        * By default canvas will be appended with "position: fixed;"  style.
        *
        * @param pCanvas Canvas.
        * @param pParent Parent HTML element.
        */
        function setup(pCanvas, pParent) {
            if (typeof pParent === "undefined") { pParent = document.body; }
            var pCanvasElement = pCanvas.getElement();
            var pDiv = document.createElement("div");

            pParent.appendChild(pDiv);
            pDiv.appendChild(pCanvasElement);
            pDiv.style.position = "fixed";
        }
        std.setup = setup;

        /**
        * �reate a camera at @vPos, and looks into center of the stage.
        * @param pScene Scene.
        * @param vPos Camera position.
        * @return Created camera.
        */
        function createCamera(pScene, vPos) {
            if (typeof vPos === "undefined") { vPos = akra.Vec3.temp(0., 0., .0); }
            var pCamera = pScene.createCamera();

            pCamera.attachToParent(pScene.getRootNode());
            pCamera.setPosition(vPos);
            pCamera.lookAt(akra.Vec3.temp(0., 0., 0.));

            pCamera.update();

            return pCamera;
        }
        std.createCamera = createCamera;

        /**
        * Create light point at @vPos and look at @vTarget.
        * @param pScene Scene.
        * @param eType Type of light.
        * @return Light point;
        */
        function createLighting(pScene, eType, vPos, vTarget) {
            if (typeof eType === "undefined") { eType = 2 /* OMNI */; }
            if (typeof vPos === "undefined") { vPos = null; }
            if (typeof vTarget === "undefined") { vTarget = null; }
            var pLight = pScene.createLightPoint(eType, true, 512, "omni-light-" + akra.guid());

            pLight.attachToParent(pScene.getRootNode());
            pLight.setEnabled(true);

            switch (eType) {
                case 2 /* OMNI */:
                case 1 /* PROJECT */:
                    //IOmniParameters & IProjectParameters same.
                    var pParams = pLight.getParams();
                    pParams.ambient.set(0.1, 0.1, 0.1, 1);
                    pParams.diffuse.set(0.5);
                    pParams.specular.set(1, 1, 1, 1);
                    pParams.attenuation.set(1, 0, 0);
            }

            if (!akra.isNull(vPos)) {
                pLight.setPosition(vPos);
            }

            if (!akra.isNull(vTarget)) {
                pLight.lookAt(vTarget);
            }

            return pLight;
        }
        std.createLighting = createLighting;

        /**
        * Create keymap. Control camera via W,S,A,D and mouse.
        * @param pViewport Viewport where keymap will be work.
        * @param pCamera. If camera not specified, will be used camera from @pViewport.
        */
        function createKeymap(pViewport, pCamera) {
            if (typeof pCamera === "undefined") { pCamera = null; }
            var pCanvas = pViewport.getTarget().getRenderer().getDefaultCanvas();
            var pKeymap = akra.control.createKeymap();

            if (akra.isNull(pCamera)) {
                pCamera = pViewport.getCamera();
            }

            pKeymap.captureMouse(pCanvas.getElement());
            pKeymap.captureKeyboard(document);

            var pScene = pCamera.getScene();

            pScene.beforeUpdate.connect(function () {
                if (pKeymap.isMousePress() && pKeymap.isMouseMoved()) {
                    var v2fMouseShift = pKeymap.getMouseShift();

                    var fdX = v2fMouseShift.x / pViewport.getActualWidth() * 10.0;
                    var fdY = v2fMouseShift.y / pViewport.getActualHeight() * 10.0;

                    pCamera.setRotationByXYZAxis(-fdY, -fdX, 0);

                    var fSpeed = 0.1 * 10;
                    if (pKeymap.isKeyPress(87 /* W */)) {
                        pCamera.addRelPosition(0, 0, -fSpeed);
                    }
                    if (pKeymap.isKeyPress(83 /* S */)) {
                        pCamera.addRelPosition(0, 0, fSpeed);
                    }
                    if (pKeymap.isKeyPress(65 /* A */)) {
                        pCamera.addRelPosition(-fSpeed, 0, 0);
                    }
                    if (pKeymap.isKeyPress(68 /* D */)) {
                        pCamera.addRelPosition(fSpeed, 0, 0);
                    }
                }
            });

            return pKeymap;
        }
        std.createKeymap = createKeymap;

        /**
        * Create default scene objects: scene surface, scene plane.
        */
        function createSceneEnvironment(pScene, bCreateQuad, bCreateSurface, fSize) {
            if (typeof bCreateQuad === "undefined") { bCreateQuad = true; }
            if (typeof bCreateSurface === "undefined") { bCreateSurface = true; }
            if (typeof fSize === "undefined") { fSize = 100; }
            if (bCreateQuad) {
                var pSceneQuad = akra.addons.createQuad(pScene, fSize * 5.);
                pSceneQuad.attachToParent(pScene.getRootNode());
            }

            if (bCreateSurface) {
                var pSceneSurface = akra.addons.createSceneSurface(pScene, fSize);

                pSceneSurface.addPosition(0, -0.01, 0);
                pSceneSurface.attachToParent(pScene.getRootNode());
            }
        }
        std.createSceneEnvironment = createSceneEnvironment;

        /** Create model entry from Collada pool by name @sResource */
        function createModelEntry(pScene, sResource) {
            var pRmgr = pScene.getManager().getEngine().getResourceManager();
            var pModel = pRmgr.getColladaPool().findResource(sResource);
            var pModelRoot = pModel.attachToScene(pScene);

            return pModelRoot;
        }
        std.createModelEntry = createModelEntry;

        function createSky(pScene, fTime) {
            if (typeof fTime === "undefined") { fTime = 14.0; }
            var pEngine = pScene.getManager().getEngine();
            var pSky = new akra.model.Sky(pEngine, 32, 32, 1000.0);
            pSky.setTime(fTime);
            pSky.skyDome.attachToParent(pScene.getRootNode());
            return pSky;
        }
        std.createSky = createSky;
    })(akra.std || (akra.std = {}));
    var std = akra.std;
})(akra || (akra = {}));
/// <reference path="../../../built/Lib/akra.d.ts" />
/// <reference path="../../../built/Lib/base3dObjects.addon.d.ts" />
/// <reference path="../../../built/Lib/progress.addon.d.ts" />
/// <reference path="../../../built/Lib/filedrop.addon.d.ts" />
/// <reference path="../std/std.ts" />
/// <reference path="../idl/3d-party/dat.gui.d.ts" />

var akra;
(function (akra) {
    var pProgress = new akra.addons.Progress(document.getElementById("progress"));

    var pRenderOpts = {
        premultipliedAlpha: true,
        preserveDrawingBuffer: true,
        antialias: true,
        depth: true
    };

    var pOptions = {
        renderer: pRenderOpts,
        progress: pProgress.getListener(),
        deps: { files: [{"path":"data.ara","type":"ara"}, {"path":"data2.map","type":"map"}], root: "./" }
    };

    var pEngine = akra.createEngine(pOptions);

    var pScene = pEngine.getScene();

    var pCanvas = pEngine.getRenderer().getDefaultCanvas();
    var pCamera = null;
    var pViewport = null;
    var pReflectionCamera = null;
    var pReflectionViewport = null;
    var pReflectionTexture = null;
    var pMirror = null;
    var pRmgr = pEngine.getResourceManager();

    var pSkyboxTexture = null;
    var pSkyboxTextures = null;
    var pEnvTexture = null;
    var pDepthViewport = null;

    var pGUI = null;

    akra.pCameraParams = {
        current: {
            orbitRadius: 6,
            rotation: new akra.math.Vec2(0., 0.)
        },
        target: {
            orbitRadius: 6,
            rotation: new akra.math.Vec2(0., 0.)
        }
    };

    akra.pModelTable = null;
    akra.pModels = null;
    akra.pCurrentModel = null;
    akra.pPodiumModel = null;

    function createCamera() {
        var pCamera = pScene.createCamera();

        pCamera.attachToParent(pScene.getRootNode());
        pCamera.setPosition(akra.Vec3.temp(0., 0., 4.2));

        pCamera.update();

        return pCamera;
    }

    function animateCameras() {
        pScene.beforeUpdate.connect(function () {
            pCamera.update();
            pReflectionCamera.update();

            var newRot = akra.math.Vec2.temp(akra.pCameraParams.current.rotation).add(akra.math.Vec2.temp(akra.pCameraParams.target.rotation).subtract(akra.pCameraParams.current.rotation).scale(0.15));
            var newRad = akra.pCameraParams.current.orbitRadius * (1. + (akra.pCameraParams.target.orbitRadius - akra.pCameraParams.current.orbitRadius) * 0.03);

            akra.pCameraParams.current.rotation.set(newRot);
            akra.pCameraParams.current.orbitRadius = newRad;
            pCamera.setPosition(newRad * -akra.math.sin(newRot.x) * akra.math.cos(newRot.y), newRad * akra.math.sin(newRot.y), newRad * akra.math.cos(newRot.x) * akra.math.cos(newRot.y));
            pCamera.lookAt(akra.math.Vec3.temp(0, 0, 0));

            pCamera.update();

            var dist = akra.math.Vec3.temp(pCamera.getWorldPosition()).subtract(pMirror.getWorldPosition());
            var up = pMirror.getTempVectorUp();

            pReflectionCamera.setPosition(akra.math.Vec3.temp(pCamera.getWorldPosition()).add(akra.math.Vec3.temp(up).scale(-2. * (up.dot(dist)))));
            pReflectionCamera.setRotationByForwardUp(pCamera.getTempVectorForward().add(akra.math.Vec3.temp(up).scale(-2. * up.dot(pCamera.getTempVectorForward()))), pCamera.getTempVectorUp().add(akra.math.Vec3.temp(up).scale(-2. * up.dot(pCamera.getTempVectorUp()))));
            pReflectionCamera.setAspect(pCamera.getAspect());

            pReflectionCamera.update();
        });
    }

    var iXPrev = 0, iYPrev = 0;
    function cameraRotationCallback(pViewport, eBtn, x, y, dx, dy) {
        if (eBtn !== 1 /* LEFT */)
            return;

        dx = x - iXPrev;
        dy = y - iYPrev;

        akra.pCameraParams.target.rotation.y = akra.math.clamp(akra.pCameraParams.target.rotation.y - dy / pViewport.getActualHeight() * 2., 0.1, 1.2);
        akra.pCameraParams.target.rotation.x += dx / pViewport.getActualHeight() * 2.;

        iXPrev = x;
        iYPrev = y;
    }

    function createKeymap(pCamera) {
        pViewport.dragstart.connect(function (pViewport, eBtn, x, y) {
            iXPrev = x;
            iYPrev = y;
        });

        pViewport.dragging.connect(cameraRotationCallback);

        pViewport.enableSupportForUserEvent(512 /* MOUSEWHEEL */ | 256 /* DRAGGING */ | 64 /* DRAGSTART */ | 128 /* DRAGSTOP */);

        pViewport.mousewheel.connect(function (pViewport, x, y, fDelta) {
            //console.log("mousewheel moved: ",x,y,fDelta);
            akra.pCameraParams.target.orbitRadius = akra.math.clamp(akra.pCameraParams.target.orbitRadius - fDelta / pViewport.getActualHeight() * 2., 2., 15.);
        });
    }

    function setupMaterialPicking(pViewport, pList) {
        var pControls = pGUI.addFolder("material");
        pControls.open();

        var pNames = [];

        if (pList) {
            pList.forEach(function (pMat) {
                pNames.push(pMat.name);
            });
        }

        var pMat = {
            list: null,
            origin: null,
            surface: null,
            name: "unknown", glossiness: 1e-2, transparency: 1e-2,
            diffuse: "#000000", ambient: "#000000", emissive: "#000000", specular: "#000000",
            texture: false
        };

        function chose(pOrigin, pSurfaceMaterial) {
            if (typeof pSurfaceMaterial === "undefined") { pSurfaceMaterial = null; }
            pMat.surface = pSurfaceMaterial;
            pMat.origin = pOrigin;
            pMat.name = pOrigin.name;
            pMat.glossiness = pOrigin.shininess;
            pMat.transparency = pOrigin.transparency;
            pMat.diffuse = pOrigin.diffuse.getHtml();
            pMat.emissive = pOrigin.emissive.getHtml();
            pMat.specular = pOrigin.specular.getHtml();

            if (pSurfaceMaterial) {
                pMat.texture = pSurfaceMaterial.texture(0 /* DIFFUSE */) !== null && !pSurfaceMaterial.texture(0 /* DIFFUSE */).isResourceDisabled();
            }
        }

        pControls.add(pMat, "list", pNames).name("material").onChange(function (sName) {
            chose(pList[pNames.indexOf(sName)], null);
        });

        pControls.add(pMat, "name").listen();
        pControls.add(pMat, "glossiness", 0., 1.).listen().onChange(function () {
            if (pMat.origin) {
                pMat.origin.shininess = pMat.glossiness;
            }
        });

        pControls.add(pMat, "transparency", 0., 1.).listen().onChange(function () {
            if (pMat.origin) {
                pMat.origin.transparency = pMat.transparency;
            }
        });

        pControls.addColor(pMat, "diffuse").listen().onChange(function () {
            if (pMat.origin) {
                pMat.origin.diffuse.set(pMat.diffuse);
            }
        });

        pControls.addColor(pMat, "emissive").listen().onChange(function () {
            if (pMat.origin) {
                pMat.origin.emissive.set(pMat.emissive);
            }
        });
        pControls.addColor(pMat, "specular").listen().onChange(function () {
            if (pMat.origin) {
                pMat.origin.specular.set(pMat.specular);
            }
        });

        pControls.add(pMat, "texture").listen().name("diffuse texture").onChange(function (bValue) {
            if (pMat.surface) {
                if (pMat.surface.texture(0 /* DIFFUSE */)) {
                    if (bValue) {
                        pMat.surface.texture(0 /* DIFFUSE */).notifyRestored();
                    } else {
                        pMat.surface.texture(0 /* DIFFUSE */).notifyDisabled();
                    }

                    pMat.surface.notifyAltered();
                }
            }
        });

        if (pViewport.getType() !== 6 /* FORWARDVIEWPORT */) {
            pViewport.enableSupportForUserEvent(1 /* CLICK */);
            pViewport.enable3DEvents(false);
            pViewport.click.connect(function (pViewport, x, y) {
                var pResult = pViewport.pick(x, y);
                pViewport.highlight(pResult);

                if (pResult.renderable) {
                    pResult.renderable.switchRenderMethod(null);
                    if (pResult.renderable.getSurfaceMaterial()) {
                        var pOrigin = pResult.renderable.getMaterial();

                        chose(pOrigin, pResult.renderable.getSurfaceMaterial());
                    }
                }
            });
        }
    }

    function createViewport() {
        var pViewport = new akra.render.DSViewport(pCamera, 0., 0., 1., 1., 11);
        pCanvas.addViewport(pViewport);
        pCanvas.resize(window.innerWidth, window.innerHeight);

        window.onresize = function (event) {
            pCanvas.resize(window.innerWidth, window.innerHeight);
        };

        var counter = 0;
        var pEffect = pViewport.getEffect();

        pGUI = new dat.GUI();

        pViewport.getEffect().addComponent("akra.system.linearFog");
        pViewport.getEffect().addComponent("akra.system.exponentialFog");

        //pViewport.getEffect().addComponent("akra.system.skybox_advanced", 1, 0);
        var fogType = {
            None: 0,
            linear: 1,
            exp: 2
        };

        var pFogData = {
            fogColor: 0,
            fogStart: 30,
            fogIndex: 30
        };

        var pFogFolder = pGUI.addFolder("fog");
        var iFogType = 0;
        pFogFolder.add({ FogType: "exp" }, 'FogType', Object.keys(fogType)).name("Type of fog").onChange(function (sKey) {
            iFogType = fogType[sKey];
        });
        pFogFolder.add(pFogData, 'fogColor').min(0.).max(1.).step(0.01).name("color").__precision = 2;
        pFogFolder.add(pFogData, 'fogStart').min(0.).max(200.).step(0.01).name("start");
        pFogFolder.add(pFogData, 'fogIndex').min(0.01).max(200.).step(0.01).name("index");

        //var fSkyboxSharpness: float = 1.;
        //pGUI.add({ skybox_sharpness: fSkyboxSharpness }, "skybox_sharpness", 0., 1., 0.01).onChange((fValue) => {
        //	fSkyboxSharpness = fValue;
        //})
        pViewport.render.connect(function (pViewport, pTechnique, iPass, pRenderable, pSceneObject) {
            var pPass = pTechnique.getPass(iPass);

            if (iFogType == 0) {
                pPass.setForeign("USE_LINEAR_FOG", false);
                pPass.setForeign("USE_EXPONENTIAL_FOG", false);
            } else if (iFogType == 1) {
                pPass.setForeign("USE_LINEAR_FOG", true);
                pPass.setForeign("USE_EXPONENTIAL_FOG", false);
            } else if (iFogType == 2) {
                pPass.setForeign("USE_LINEAR_FOG", false);
                pPass.setForeign("USE_EXPONENTIAL_FOG", true);
            }
            pPass.setUniform("FOG_COLOR", new akra.math.Vec3(pFogData.fogColor));
            pPass.setUniform("FOG_START", pFogData.fogStart);
            pPass.setUniform("FOG_INDEX", pFogData.fogIndex);
            //pPass.setUniform("SKYBOX_ADVANCED_SHARPNESS", fSkyboxSharpness);
            //pPass.setTexture("SKYBOX_UNWRAPED_TEXTURE", pEnvTexture);
        });

        var pSkyboxTexturesKeys = [
            'nightsky',
            'desert',
            'nature',
            'colosseum',
            'beach',
            'plains',
            'church',
            'basilica'
        ];

        pSkyboxTextures = {};

        for (var i = 0; i < pSkyboxTexturesKeys.length; i++) {
            pSkyboxTextures[pSkyboxTexturesKeys[i]] = pRmgr.createTexture(".sky-box-texture-" + pSkyboxTexturesKeys[i]);
            (pSkyboxTextures[pSkyboxTexturesKeys[i]]).loadResource("SKYBOX_" + pSkyboxTexturesKeys[i].toUpperCase());
        }

        var pPBSFolder = pGUI.addFolder("pbs");

        pPBSFolder.add({ Skybox: "nightsky" }, 'Skybox', pSkyboxTexturesKeys).name("Skybox").onChange(function (sKey) {
            pViewport.setSkybox(pSkyboxTextures[sKey]);

            pEnvTexture.unwrapCubeTexture(pSkyboxTextures[sKey]);
        });

        pViewport.setShadingModel(2 /* PBS_SIMPLE */);

        return pViewport;
    }

    //function wheels() {
    //	var wheels = [];
    //	pScene.getRootNode().explore(function (node) {
    //		if ((node.getName() || "").indexOf("node-wheel") !== -1) {
    //			wheels.push(node);
    //		}
    //		return true;
    //	})
    //	pGUI.add({ wheels_rotation: 0 }, "wheels_rotation", 0, 360, 0.1).onChange((fAngle: float) => {
    //		var fRad = fAngle * math.RADIAN_RATIO;
    //		wheels.forEach((pWheel: INode) => {
    //			pWheel.setRotationByXYZAxis(0, fRad, 0);
    //		});
    //	})
    //}
    function createMirror() {
        var pNode = pScene.createNode().setPosition(0., -1.5, 0.);
        pNode.setInheritance(3 /* ROTPOSITION */);
        pReflectionCamera = createMirrorCamera(pNode);
        pReflectionViewport = createMirrorViewport(pNode);

        return pNode;
    }

    function createMirrorCamera(pReflNode) {
        var pReflectionCamera = pScene.createCamera("reflection_camera_01");

        pReflectionCamera.attachToParent(pScene.getRootNode());
        pReflectionCamera.setInheritance(pCamera.getInheritance());

        return pReflectionCamera;
    }

    function createMirrorViewport(pReflNode) {
        pReflectionTexture = pRmgr.createTexture(".reflection_texture");
        pReflectionTexture.create(1024, 1024, 1, null, 512 /* RENDERTARGET */, 0, 0, 3553 /* TEXTURE_2D */, 10 /* R8G8B8 */);

        var pRenderTarget = pReflectionTexture.getBuffer().getRenderTarget();
        pRenderTarget.setAutoUpdated(false);

        var pTexViewport = pRenderTarget.addViewport(new akra.render.MirrorViewport(pReflectionCamera, 0., 0., 1., 1., 0));
        var pEffect = pTexViewport.getInternalViewport().getEffect();

        //pEffect.addComponent("akra.system.blur");
        pTexViewport.getInternalViewport().render.connect(function (pViewport, pTechnique, iPass, pRenderable, pSceneObject) {
            var pPass = pTechnique.getPass(iPass);
            pPass.setUniform("BLUR_RADIUS", 2.0);
        });

        return pTexViewport;
    }

    var lightPos1 = new akra.math.Vec3(1, 2, 2);
    var lightPos2 = new akra.math.Vec3(-1, -2, 2);

    akra.pOmniLights = null;
    function createLighting() {
        akra.pOmniLights = pScene.createNode('lights-root');
        akra.pOmniLights.attachToParent(pCamera);
        akra.pOmniLights.setInheritance(4 /* ALL */);

        var pOmniLight;
        var pOmniLightSphere;

        pOmniLight = pScene.createLightPoint(2 /* OMNI */, true, 2048, "test-omni-0");

        pOmniLight.attachToParent(akra.pOmniLights);
        pOmniLight.setEnabled(true);
        pOmniLight.getParams().ambient.set(0.1);
        pOmniLight.getParams().diffuse.set(1.0, 1.0, 1.0);
        pOmniLight.getParams().specular.set(1.0, 1.0, 1.0, 1.0);
        pOmniLight.getParams().attenuation.set(1, 0, 0.3);
        pOmniLight.setShadowCaster(true);
        pOmniLight.setInheritance(4 /* ALL */);

        pOmniLight.setPosition(lightPos1);

        pOmniLight = pScene.createLightPoint(2 /* OMNI */, true, 512, "test-omni-0");

        pOmniLight.attachToParent(akra.pOmniLights);
        pOmniLight.setEnabled(true);
        pOmniLight.getParams().ambient.set(0.1);
        pOmniLight.getParams().diffuse.set(1.0, 1.0, 1.0);
        pOmniLight.getParams().specular.set(1.0, 1.0, 1.0, 1.0);
        pOmniLight.getParams().attenuation.set(1, 0, 0.3);
        pOmniLight.setShadowCaster(false);
        pOmniLight.setInheritance(4 /* ALL */);

        pOmniLight.setPosition(lightPos2);
    }

    function createSkyBox() {
        pSkyboxTexture = pSkyboxTextures['nightsky'];

        if (pViewport.getType() === 6 /* FORWARDVIEWPORT */) {
            var pCube = pRmgr.loadModel("CUBE.DAE");
            var pModel = pCube.extractModel("box");

            pViewport._setSkyboxModel(pModel.getRenderable(0));
        }

        pViewport.setSkybox(pSkyboxTexture);

        pEnvTexture = pRmgr.createTexture(".env-map-texture-01");
        pEnvTexture.create(1024, 512, 1, null, 0, 0, 0, 3553 /* TEXTURE_2D */, 10 /* R8G8B8 */);
        pEnvTexture.unwrapCubeTexture(pSkyboxTexture);

        pViewport.setDefaultEnvironmentMap(pEnvTexture);
        (pReflectionViewport.getInternalViewport()).setDefaultEnvironmentMap(pEnvTexture);
        (pReflectionViewport.getInternalViewport()).setShadingModel(2 /* PBS_SIMPLE */);
    }

    function createStatsDIV() {
        var pStatsDiv = document.createElement("div");

        document.body.appendChild(pStatsDiv);
        pStatsDiv.setAttribute("style", "position: fixed;" + "max-height: 40px;" + "max-width: 120px;" + "color: green;" + "margin: 5px;" + "font-family: Arial;");

        return pStatsDiv;
    }

    function main(pEngine) {
        akra.std.setup(pCanvas);

        pCamera = createCamera();
        pViewport = createViewport();
        pMirror = createMirror();
        pViewport.setBackgroundColor(akra.color.GRAY);
        pViewport.setClearEveryFrame(true);

        var pStatsDiv = createStatsDIV();

        pCanvas.postUpdate.connect(function (pCanvas) {
            pStatsDiv.innerHTML = pCanvas.getAverageFPS().toFixed(2) + " fps";
        });

        createKeymap(pCamera);

        animateCameras();

        window.onresize = function () {
            pCanvas.resize(window.innerWidth, window.innerHeight);
        };

        createLighting();
        createSkyBox();

        var pPlasticMaterial = new akra.material.Material();
        pPlasticMaterial.shininess = 0.176;

        //pPlasticMaterial.set("plastic");
        pPlasticMaterial.diffuse.set("#bbbbbb");
        pPlasticMaterial.specular.set("#4a4a4a");

        var iTableRadius = 3.15;
        var iTableHeight = 0;

        akra.pModelTable = akra.addons.trifan(pScene, iTableRadius, 96);
        akra.pModelTable.attachToParent(pScene.getRootNode());
        akra.pModelTable.setPosition(0., iTableHeight, 0.);

        var pAnimate = { animate: true };
        pGUI.add(pAnimate, "animate");

        pScene.beforeUpdate.connect(function () {
            if (!pAnimate.animate)
                return;
            akra.pModelTable.addRelRotationByXYZAxis(0., 0.001, 0.);
        });

        //var pBottomLight: IOmniLight = <IOmniLight>pScene.createLightPoint(ELightTypes.OMNI, false);
        //pBottomLight.attachToParent(pModelTable);
        //pBottomLight.getParams().diffuse.set(color.GREEN);
        //pBottomLight.getParams().attenuation.set(1., 0., 0.);
        function createSceneLights() {
            var h = 1.;
            var d = 200;
            var iPower = 1.;

            var pGroundLight = window["ground_light"] = pScene.createLightPoint(2 /* OMNI */, false);
            pGroundLight.attachToParent(akra.pModelTable);
            pGroundLight.setInheritance(1 /* POSITION */);
            pGroundLight.restrictLight(true, akra.geometry.Rect3d.temp(akra.Vec3.temp(-1, 0, -1), akra.Vec3.temp(1, .25, 1)));
            pGroundLight.setPosition(0., 0., 0.);
            pGroundLight.getParams().attenuation.set(.7, .2, 0.);
            pGroundLight.getParams().diffuse.set(akra.color.LIGHT_BLUE);
            pGroundLight.getParams().specular.set(akra.color.LIGHT_BLUE);
        }

        createSceneLights();

        var pModelTableSubset = akra.pModelTable.getMesh().getSubset(0);

        var pMat = pModelTableSubset.getMaterial();
        pMat.diffuse.set("#525252");
        pMat.specular.set("#878787");
        pMat.shininess = 0.871;

        pModelTableSubset.getTechnique().render.connect(function (pTech, iPass, pRenderable, pSceneObject, pLocalViewport) {
            pTech.getPass(iPass).setTexture("MIRROR_TEXTURE", pReflectionTexture);
            pTech.getPass(iPass).setForeign("IS_USED_MIRROR_REFLECTION", true);
        });

        var iCylinderHeight = .025;
        var pCylinder = akra.addons.cylinder(pScene, iTableRadius, iTableRadius, iCylinderHeight, 96, 1.);
        pCylinder.attachToParent(akra.pModelTable);
        pCylinder.setPosition(0., -iCylinderHeight / 2, 0.);
        var pCylinderSubset = pCylinder.getMesh().getSubset(0);
        pCylinderSubset.getMaterial().shininess = 0.7;

        //pCylinderSubset.getSurfaceMaterial().setMaterial(pPlasticMaterial);
        var pMat = pCylinderSubset.getMaterial();
        pMat.emissive.set("#00ff00");
        pMat.diffuse.set("#000000");
        pMat.specular.set("#6e6e6e");
        pMat.shininess = 0.;

        var pSurface = akra.addons.createQuad(pScene, 100);
        pSurface.attachToParent(pScene.getRootNode());
        pSurface.setPosition(0., iTableHeight - iCylinderHeight, 0.);

        //var pPodiumLight: IOmniLight = window["podium_light"] = <IOmniLight>pScene.createLightPoint(ELightTypes.OMNI, false);
        //pPodiumLight.attachToParent(pSurface);
        //pPodiumLight.setPosition(0., 0.025 / 2, .0);
        //var fGroundLightRadius: float = iTableRadius + 1.
        //pPodiumLight.restrictLight(true, geometry.Rect3d.temp(-fGroundLightRadius, fGroundLightRadius, -1, 0.025 / 2, -fGroundLightRadius, fGroundLightRadius));
        //pPodiumLight.getParams().attenuation.x = .001;
        //pPodiumLight.getParams().diffuse.set(color.LIGHT_GREEN);
        var pLightMap = window["light_map"] = akra.addons.createQuad(pScene);
        pLightMap.attachToParent(pSurface);
        pLightMap.setPosition(0., 1e-3, 0);
        pLightMap.getMesh().setShadow(false);
        pLightMap.getMesh().getSubset(0).getSurfaceMaterial().setTexture(0, "LIGHTMAP.PNG", 3 /* EMISSIVE */);
        pLightMap.getMesh().getSubset(0).getSurfaceMaterial().texture(0).setFilter(10240 /* MAG_FILTER */, 9729 /* LINEAR */);
        pLightMap.getMesh().getSubset(0).getSurfaceMaterial().texture(0).setFilter(10241 /* MIN_FILTER */, 9729 /* LINEAR */);
        pLightMap.setLocalScale(akra.Vec3.temp(pViewport.getType() === 6 /* FORWARDVIEWPORT */ ? 0.1795 : 0.1865));
        pLightMap.getMesh().getSubset(0).getMaterial().emissive.set(.3, 1., .3, 1.);
        pLightMap.getMesh().getSubset(0).getMaterial().diffuse.set(0., 0., 0., 0.);
        pLightMap.getMesh().getSubset(0).getMaterial().specular.set(0., 0., 0., 0.);
        pLightMap.getMesh().getSubset(0).getMaterial().ambient.set(0., 0., 0., 0.);
        pLightMap.getMesh().getSubset(0).getMaterial().transparency = 0.99;

        pGUI.add({ glow: true }, "glow").onChange(function (bValue) {
            pLightMap.getRenderable(0).setVisible(bValue);
        });

        //var pSurfMat = pSurface.getMesh().getSubset(0).getSurfaceMaterial().setMaterial(pPlasticMaterial);
        var pMat = pSurface.getMesh().getSubset(0).getMaterial();
        pMat.emissive.set("#000000");
        pMat.diffuse.set("#464646");
        pMat.specular.set("#0f0f0f");
        pMat.shininess = 0.386;

        var pMercedes = pScene.createNode("mercedes");
        var pModel = pEngine.getResourceManager().loadModel("MERCEDES.DAE");

        pMercedes.setInheritance(3 /* ROTPOSITION */);
        pModel.attachToScene(pMercedes);

        pMercedes.attachToParent(akra.pModelTable);

        pMirror.attachToParent(akra.pModelTable);
        pMirror.setPosition(0., 0., 0.);

        setupMaterialPicking(pViewport, pModel.extractUsedMaterials());

        pGUI.add({
            "save": function () {
                saveAs(pModel.toBlob(), "mercedes.DAE");
            }
        }, "save");

        pGUI.add({
            "save materials": function () {
                var pMaterials = pModel.extractUsedMaterials();
                var pExporter = new akra.exchange.Exporter();

                pMaterials.forEach(function (pMat) {
                    pExporter.writeMaterial(pMat);
                });

                pExporter.saveAs(prompt("enter skin name", "unknown") + ".skin", 0 /* JSON */);
            }
        }, "save materials");

        pCanvas.viewportPreUpdate.connect(function (pTarget, pInputViewport) {
            if (pInputViewport === pViewport) {
                var normal = pMirror.getTempVectorUp();
                var dist = pMirror.getWorldPosition().dot(normal);
                pReflectionViewport.getReflectionPlane().set(normal, dist);
                if (pMirror.getTempVectorUp().dot(akra.math.Vec3.temp(pCamera.getWorldPosition()).subtract(pMirror.getWorldPosition())) > 0.) {
                    pReflectionTexture.getBuffer().getRenderTarget().update();
                }
            }
        });

        if (akra.config.DEBUG) {
            akra.addons.filedrop.addHandler(document.body, {
                drop: (function (pFile, sContent, eFormat, e) {
                    var pImporter = new akra.exchange.Importer(pEngine);
                    pImporter.import(sContent, 0 /* JSON */);

                    var pMaterials = pImporter.getMaterials();
                    var pUsedMaterials = pModel.extractUsedMaterials();

                    var pMaterialsMap = {};

                    pMaterials.forEach(function (pMat) {
                        pMaterialsMap[pMat.name] = pMat;
                    });

                    pUsedMaterials.forEach(function (pMat, i) {
                        if (pMaterialsMap[pMat.name]) {
                            pMat.set(pMaterialsMap[pMat.name]);
                        }
                    });
                }),
                verify: function (pFile, e) {
                    return akra.path.parse(pFile.name).getExt() === "skin";
                }
            });
        }

        //wheels();
        pProgress.destroy();
        pEngine.exec();

        cameraRotationCallback(pViewport, 1 /* LEFT */, 0, 0, 0, 0);
    }

    pEngine.depsLoaded.connect(main);
})(akra || (akra = {}));
